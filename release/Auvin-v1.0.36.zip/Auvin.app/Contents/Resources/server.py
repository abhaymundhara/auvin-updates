import json
import os
import subprocess
import sys
import time
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path

import httpx

from redislite.falkordb_client import FalkorDB

try:
    from memory_search import score_memory_match
except ImportError:
    import re

    def score_memory_match(query: str, key: str, content: str) -> int:
        query_text = query.strip().lower()
        key_text = (key or "").lower()
        content_text = (content or "").lower()
        if not query_text:
            return 0

        score = 8 if query_text in key_text else 0
        if query_text in content_text:
            score += 5
        for term in re.findall(r"[a-z0-9]+", query_text):
            if term in key_text:
                score += 4
            if term in content_text:
                score += 2
        return score


SIDECAR_DIR = Path(__file__).parent
SEARXNG_PORT = 8888
SEARXNG_URL = f"http://127.0.0.1:{SEARXNG_PORT}"
SIDECAR_TOKEN = os.environ.get('AUVIN_SIDECAR_TOKEN', '')

ALLOWED_RPC_METHODS = frozenset({
    'memory_append', 'memory_get', 'memory_search',
    'memory_all', 'health', 'diagnostic',
    'web_search', 'extract_profile',
})


class SearXNGProcess:
    def __init__(self):
        self.process = None
        self._stderr_thread = None

    def _find_settings(self):
        candidates = [
            Path(os.environ.get("SEARXNG_SETTINGS_PATH", "")),
            SIDECAR_DIR / "searxng" / "settings.yml",
            Path.cwd() / "searxng" / "settings.yml",
            Path.cwd().parent / "searxng" / "settings.yml",
        ]
        for p in candidates:
            if p and p.exists():
                return p
        return None

    def _drain_stderr(self, pipe):
        try:
            for line in iter(pipe.readline, ""):
                line = line.strip()
                if line:
                    print(f"SEARXNG_WARN {line}", flush=True)
        except Exception:
            pass

    def start(self):
        self._try_start()

    def _free_port(self):
        import subprocess as _sp
        try:
            result = _sp.run(['lsof', '-ti', f':{SEARXNG_PORT}'], capture_output=True, text=True, timeout=3)
            if result.stdout.strip():
                for pid in result.stdout.strip().split('\n'):
                    pid = pid.strip()
                    if not pid:
                        continue
                    # Only kill processes that are our SearXNG/uwsgi instances
                    ps_result = _sp.run(['ps', '-p', pid, '-o', 'comm='], capture_output=True, text=True, timeout=3)
                    proc_name = ps_result.stdout.strip().lower()
                    if 'searx' in proc_name or 'uwsgi' in proc_name or 'python' in proc_name:
                        _sp.run(['kill', '-15', pid], capture_output=True, timeout=3)
                import time
                time.sleep(1)
                # SIGKILL any remaining
                result = _sp.run(['lsof', '-ti', f':{SEARXNG_PORT}'], capture_output=True, text=True, timeout=3)
                if result.stdout.strip():
                    for pid in result.stdout.strip().split('\n'):
                        pid = pid.strip()
                        if not pid:
                            continue
                        ps_result = _sp.run(['ps', '-p', pid, '-o', 'comm='], capture_output=True, text=True, timeout=3)
                        proc_name = ps_result.stdout.strip().lower()
                        if 'searx' in proc_name or 'uwsgi' in proc_name or 'python' in proc_name:
                            _sp.run(['kill', '-9', pid], capture_output=True, timeout=3)
        except Exception:
            pass

    def _launch(self):
        settings_path = self._find_settings()
        env = os.environ.copy()
        env["SEARXNG_SETTINGS_PATH"] = str(settings_path)
        self.process = subprocess.Popen(
            [sys.executable, "-m", "searx.webapp"],
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
        )
        import threading
        self._stderr_thread = threading.Thread(
            target=self._drain_stderr, args=(self.process.stderr,), daemon=True
        )
        self._stderr_thread.start()

    def _try_start(self):
        self._free_port()
        if self._find_settings() is None:
            print("SEARXNG_WARN searxng/settings.yml not found, web search unavailable", flush=True)
            return False
        try:
            self._launch()
            self._wait_ready()
            return True
        except Exception as e:
            print(f"SEARXNG_WARN failed to start SearXNG: {e}", flush=True)
            self.stop()
            return False

    def _wait_ready(self, timeout=20):
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                r = httpx.get(f"{SEARXNG_URL}/search", params={"q": "ping", "format": "json"}, timeout=2)
                if r.status_code == 200:
                    print(f"SEARXNG_READY {SEARXNG_PORT}", flush=True)
                    return
            except Exception:
                pass
            time.sleep(0.5)
        print("SEARXNG_WARN SearXNG did not start in time", flush=True)

    def stop(self):
        if self.process:
            self.process.terminate()
            try:
                self.process.wait(timeout=5)
            except Exception:
                self.process.kill()
            self.process = None


class MemoryServer:
    def __init__(self):
        self.db = FalkorDB()
        self.graph = self.db.select_graph("memory")
        self._ensure_indices()
        self.searxng = SearXNGProcess()

    def start_searxng(self):
        self.searxng.start()

    def stop_searxng(self):
        self.searxng.stop()

    def _ensure_indices(self):
        for cypher in [
            "CREATE INDEX FOR (c:Chunk) ON (c.key)",
            "CREATE INDEX FOR (c:Chunk) ON (c.created_at)",
        ]:
            try:
                self.graph.query(cypher)
            except Exception:
                pass

    def _searxng_healthy(self):
        if self.searxng.process is None:
            return False
        if self.searxng.process.poll() is not None:
            self.searxng.process = None
            return False
        try:
            r = httpx.get(f"{SEARXNG_URL}/search", params={"q": "ping", "format": "json"}, timeout=3)
            return r.status_code == 200
        except Exception:
            return False

    def _ensure_searxng(self):
        if self._searxng_healthy():
            return True
        if self.searxng.process is not None:
            self.searxng.stop()
        return self.searxng._try_start()

    def _do_search(self, query: str, max_results: int, language: str, time_range: str = None) -> dict:
        params = {
            "q": query,
            "format": "json",
            "language": language,
            "categories": "general",
        }
        if time_range:
            params["time_range"] = time_range

        try:
            r = httpx.get(
                f"{SEARXNG_URL}/search",
                params=params,
                timeout=25,
                headers={"X-Forwarded-For": "127.0.0.1"},
            )
            r.raise_for_status()
            return r.json()
        except httpx.ConnectError:
            return {"_error": f"Could not connect to SearXNG on port {SEARXNG_PORT}"}
        except httpx.TimeoutException:
            return {"_error": "SearXNG search timed out. The search engines may be slow to respond."}
        except Exception as e:
            return {"_error": f"Web search failed: {e}"}

    def web_search(self, query: str, max_results: int = 10, language: str = "en", time_range: str = None):
        print(f"WEBSEARCH max={max_results}", flush=True)
        if not self._ensure_searxng():
            print("WEBSEARCH SearXNG not available", flush=True)
            return {"status": "error", "message": "SearXNG search engine is not available. Check that searxng/settings.yml exists.", "results": []}

        print("WEBSEARCH SearXNG healthy, searching...", flush=True)
        data = self._do_search(query, max_results, language, time_range)
        error = data.pop("_error", None)
        if error:
            print(f"WEBSEARCH initial search failed: {error}", flush=True)
            if "Could not connect" in error:
                self.searxng.stop()
                if self._ensure_searxng():
                    print("WEBSEARCH SearXNG restarted, retrying...", flush=True)
                    data = self._do_search(query, max_results, language, time_range)
                    error = data.pop("_error", None)
            if error:
                print(f"WEBSEARCH failed: {error}", flush=True)
                return {"status": "error", "message": error, "results": []}

        results = data.get("results", [])
        formatted = []
        for item in results[:max_results]:
            formatted.append({
                "title": item.get("title", ""),
                "url": item.get("url", ""),
                "content": item.get("content", ""),
                "engine": item.get("engine", ""),
            })

        suggestions = data.get("suggestions", [])
        answers = data.get("answers", [])

        return {
            "status": "ok",
            "query": query,
            "results": formatted,
            "count": len(formatted),
            "suggestions": suggestions,
            "answers": answers,
            "number_of_results": data.get("number_of_results", 0),
        }

    def memory_append(self, key: str, content: str):
        self.graph.query(
            "MERGE (c:Chunk {key: $key}) "
            "ON CREATE SET c.content = $content, c.created_at = timestamp() "
            "ON MATCH SET c.content = c.content + '\n' + $content, c.updated_at = timestamp()",
            params={"key": key, "content": content},
        )
        return {"status": "ok", "key": key}

    def memory_get(self, key: str):
        result = self.graph.query(
            "MATCH (c:Chunk {key: $key}) RETURN c.content ORDER BY c.created_at DESC LIMIT 1",
            params={"key": key},
        )
        if result.result_set:
            return {"status": "ok", "key": key, "content": result.result_set[0][0]}
        return {"status": "not_found", "key": key, "content": None}

    def memory_search(self, query: str, max_results: int = 5):
        cypher = (
            "MATCH (c:Chunk) "
            "RETURN c.key, c.content, c.created_at"
        )
        result = self.graph.query(cypher)
        results = []
        if result.result_set:
            for row in result.result_set:
                score = score_memory_match(query, row[0], row[1])
                if score > 0:
                    results.append({"key": row[0], "content": row[1], "created_at": row[2], "score": score})
        results.sort(key=lambda item: (-item["score"], -(item.get("created_at") or 0)))
        results = results[:max_results]
        for item in results:
            item.pop("score", None)
        return {"status": "ok", "results": results, "count": len(results)}

    def memory_all(self):
        result = self.graph.query(
            "MATCH (c:Chunk) WHERE c.key IS NOT NULL RETURN c.key, c.content, c.created_at, c.updated_at ORDER BY c.created_at ASC"
        )
        entries = []
        if result.result_set:
            for row in result.result_set:
                entry = {"key": row[0], "content": row[1], "created_at": row[2]}
                if len(row) > 3 and row[3] is not None:
                    entry["updated_at"] = row[3]
                entries.append(entry)
        return {"status": "ok", "entries": entries}

    def flushall(self):
        self.graph.delete()
        self.graph = self.db.select_graph("memory")
        self._ensure_indices()
        return {"status": "ok"}

    def health(self):
        try:
            self.graph.query("RETURN 1")
            return {"status": "ok"}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def diagnostic(self):
        searxng_process = self.searxng.process is not None
        searxng_alive = self._searxng_healthy()
        settings_path = str(self.searxng._find_settings() or "NOT_FOUND")
        return {
            "searxng_process_exists": searxng_process,
            "searxng_alive": searxng_alive,
            "settings_path": settings_path,
        }


memory_server = MemoryServer()


class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        # Verify bearer token
        auth_header = self.headers.get('Authorization', '')
        if SIDECAR_TOKEN and not auth_header == f'Bearer {SIDECAR_TOKEN}':
            self.send_response(401)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({'error': {'code': -32600, 'message': 'Unauthorized'}}).encode())
            return

        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length)
        req_id = None
        try:
            request = json.loads(body)
            method = request.get("method")
            params = request.get("params", {})
            req_id = request.get("id")

            if method not in ALLOWED_RPC_METHODS:
                resp = {'id': req_id, 'error': {'code': -32601, 'message': f'Method not allowed: {method}'}}
            else:
                handler = getattr(memory_server, method, None)
                if handler is None:
                    resp = {"id": req_id, "error": {"code": -32601, "message": f"Method not found: {method}"}}
                else:
                    result = handler(**params) if isinstance(params, dict) else handler(params)
                    resp = {"id": req_id, "result": result}
        except Exception as e:
            resp = {"id": req_id, "error": {"code": -32603, "message": str(e)}}

        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(resp).encode())

    def log_message(self, format, *args):
        pass


def main():
    memory_server.start_searxng()

    port = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    server = HTTPServer(("127.0.0.1", port), Handler)
    actual_port = server.server_address[1]
    print(f"SIDECAR_READY {actual_port}", flush=True)
    try:
        server.serve_forever()
    finally:
        memory_server.stop_searxng()


if __name__ == "__main__":
    main()
